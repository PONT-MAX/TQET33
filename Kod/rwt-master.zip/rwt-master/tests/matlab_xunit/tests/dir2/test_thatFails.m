function test_suite = test_thatFails
initTestSuite;

function test_case
assertTrue(false);
