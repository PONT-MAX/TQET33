% test_this.m is a function-file test case.
function test_this