path(path, '../bin')
path(path, 'matlab_xunit/xunit')
test_mdwt
test_midwt
test_mirdwt
test_mrdwt
test_makesig
test_denoise
test_setopt
test_daubcqf
