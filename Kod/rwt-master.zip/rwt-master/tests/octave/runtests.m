path('../../bin', path)
test_mdwt
test_midwt
test_mirdwt
test_mrdwt
test_makesig
test_denoise
test_setopt
