function axisfortex (t,x,y)

set(gca,'FontSize',20);
set(gcf,'DefaultTextFontSize',20);
title (t); xlabel(x); ylabel(y);

